package hello.exceoption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceoptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
